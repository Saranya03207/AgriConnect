from app.repositories.dynamodb_repo import DynamoDBRepository, get_dynamodb_repository

__all__ = ["DynamoDBRepository", "get_dynamodb_repository"]
