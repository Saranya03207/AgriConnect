"""Listings function package"""
