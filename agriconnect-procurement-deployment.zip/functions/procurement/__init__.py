"""Procurement lambda function package."""
